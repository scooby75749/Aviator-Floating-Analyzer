package com.example.aviatorfloatinganalyzer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import kotlin.math.max

class CaptureOverlayService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL = "aviator_analyzer_capture"
        private const val NOTIFICATION_ID = 73
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: TextView? = null
    private var windowManager: WindowManager? = null
    private var worker: Handler? = null
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val values = mutableListOf<Double>()
    private var lastAccepted: Double? = null
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, notification())
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val thread = HandlerThread("AviatorOCR").apply { start() }
        worker = Handler(thread.looper)
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, worker)

        showOverlay()
        startCapture()
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = "AVIATOR ANALYZER\nWaiting for visible multipliers…\nHistory: 0"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xEE171D2B.toInt())
            setPadding(18, 14, 18, 14)
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 140 }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        tv.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; true }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    windowManager?.updateViewLayout(v, params); true
                }
                else -> false
            }
        }
        overlay = tv
        windowManager?.addView(tv, params)
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        val width = dm.widthPixels
        val height = dm.heightPixels
        val density = dm.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            val image = try { source.acquireLatestImage() } catch (_: Exception) { null }
            if (image != null) processImage(image)
        }, worker)
        virtualDisplay = projection?.createVirtualDisplay(
            "AviatorVisibleScreen", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, worker
        )
    }

    private fun processImage(image: Image) {
        if (busy) { image.close(); return }
        busy = true
        try {
            val bitmap = imageToBitmap(image)
            image.close()
            val input = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(input)
                .addOnSuccessListener { result ->
                    // Only multiplier-looking text is considered. OCR can misread digits;
                    // the user should verify history entries before relying on the stats.
                    val regex = Regex("(?i)(\\d{1,5}(?:[.,]\\d{1,2})?)\\s*[x×]")
                    val found = regex.findAll(result.text).mapNotNull {
                        it.groupValues[1].replace(',', '.').toDoubleOrNull()
                    }.filter { it >= 1.0 && it <= 100000.0 }.toList()
                    val candidate = found.lastOrNull()
                    if (candidate != null && candidate != lastAccepted) {
                        lastAccepted = candidate
                        values.add(candidate)
                        if (values.size > 100) values.removeAt(0)
                    }
                    updateOverlay()
                }
                .addOnFailureListener { updateText("OCR reading issue — keep game results visible") }
                .addOnCompleteListener { bitmap.recycle(); busy = false }
        } catch (_: Exception) {
            image.close()
            busy = false
        }
    }

    private fun imageToBitmap(image: Image): android.graphics.Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val padded = android.graphics.Bitmap.createBitmap(paddedWidth, image.height, android.graphics.Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        val cropped = android.graphics.Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    private fun updateOverlay() {
        val sorted = values.sorted()
        val avg = if (values.isEmpty()) 0.0 else values.average()
        val median = if (sorted.isEmpty()) 0.0 else if (sorted.size % 2 == 1) sorted[sorted.size / 2]
                    else (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0
        val text = if (values.isEmpty()) "AVIATOR ANALYZER\nNo multiplier detected yet"
        else String.format(Locale.US,
            "AVIATOR ANALYZER\nRead: %.2fx\nRounds: %d  Avg: %.2fx\nMedian: %.2fx\nHistory only — no next-round prediction",
            values.last(), values.size, avg, median)
        updateText(text)
    }

    private fun updateText(text: String) { overlay?.post { overlay?.text = text } }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Aviator screen analysis", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Aviator Analyzer is running")
            .setContentText("Screen sharing is active. Tap Stop in the app to end.")
            .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()
    }

    override fun onDestroy() {
        try { virtualDisplay?.release(); reader?.close(); projection?.stop() } catch (_: Exception) {}
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        recognizer.close()
        super.onDestroy()
    }
}
