# Aviator Floating Analyzer (Android Studio starter)

This is a **native Android source project**, not a compiled/signed APK.

## What it does
- Requests Android's official screen-capture consent (MediaProjection).
- Displays a movable floating overlay above other apps (requires the user to grant overlay permission).
- Runs on-device ML Kit text recognition on the captured screen.
- Looks for visible multiplier strings such as `1.45x` and shows the latest detected value, count, average and median.
- Keeps the in-memory history only for the current service session.

## Important limitations
- OCR may misread numbers or detect unrelated multiplier-like text. This starter does not yet have a game-specific screen-region selector or duplicate-round confirmation UI.
- It does not access Parimatch internals, bypass app protections, or predict the next crash point. It only analyses text visible in the screen capture the user explicitly approves.
- Screen capture may be blocked or blank on secure/protected screens. Do not try to bypass those restrictions.
- Test on your own device and only where the game/platform terms and local law allow screen capture and overlays.

## Build APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder as an existing Android Studio project.
3. Let Gradle sync. Use JDK 17.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will produce a debug APK under `app/build/outputs/apk/debug/`.
6. For distribution, create your own signed release build in Android Studio.

## Run
1. Install the APK on your Android phone.
2. Open the app and allow **Display over other apps**.
3. Tap **Start screen reading** and approve Android's screen-sharing prompt.
4. Switch to the game. The floating panel should appear; move it by dragging.
5. Stop from the app; Android's screen-sharing indicator also shows capture is active.

This starter has not been compiled or device-tested in this environment. Review and test it before use.
